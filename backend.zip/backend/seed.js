require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./src/models/User'); // Перевірте правильність шляху до моделі
const Salary = require('./src/models/Salary'); // Перевірте правильність шляху до моделі

// --- НАЛАШТУВАННЯ ---
const MONGO_URI = process.env.MONGO_URI;

// --- ДАНІ КОРИСТУВАЧІВ ---
const usersData = [
  {
    name: 'Віктор Адмін',
    email: 'admin@company.com',
    password: 'password123', // У коді нижче буде замінено на хеш '123456'
    role: 'admin',
    fixedSalary: 50000
  },
  {
    name: 'Олена Бухгалтер',
    email: 'buh@company.com',
    password: 'password123',
    role: 'accountant',
    fixedSalary: 25000
  },
  {
    name: 'Ігор Керівник',
    email: 'boss@company.com',
    password: 'password123',
    role: 'manager',
    fixedSalary: 40000
  },
  // 5 Співробітників
  { name: 'Андрій Розробник', email: 'dev1@company.com', role: 'user', fixedSalary: 30000 },
  { name: 'Марія Дизайнер', email: 'design@company.com', role: 'user', fixedSalary: 28000 },
  { name: 'Олег Тестувальник', email: 'qa@company.com', role: 'user', fixedSalary: 22000 },
  { name: 'Ірина Маркетолог', email: 'mark@company.com', role: 'user', fixedSalary: 24000 },
  { name: 'Василь Менеджер', email: 'sales@company.com', role: 'user', fixedSalary: 20000 },
];

const seedDB = async () => {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('🔌 Підключено до MongoDB');

    // 1. Очищення бази (Обережно! Видалить старі дані)
    await User.deleteMany({});
    await Salary.deleteMany({});
    console.log('🗑️  Старі дані очищено');

    // 2. Створення користувачів
    const createdUsers = [];
    
    // Хешуємо пароль один раз для всіх (для швидкості)
    const hashedPassword = await bcrypt.hash('123456', 10);

    for (const u of usersData) {
      const user = await User.create({
        name: u.name,
        email: u.email,
        password: hashedPassword, // У всіх пароль "123456"
        role: u.role,
        fixedSalary: u.fixedSalary
      });
      createdUsers.push(user);
      console.log(`👤 Створено: ${user.name} (${user.role})`);
    }

    // Знаходимо ID керівника для підпису платіжок
    const manager = createdUsers.find(u => u.role === 'manager');
    // Знаходимо всіх користувачів для нарахування ЗП
    const employees = createdUsers;

    // 3. Генерація історії зарплат (2024-2025)
    console.log('💰 Починаємо нарахування зарплат...');
    
    const salaryRecords = [];
    const startDate = new Date('2024-01-01');
    const endDate = new Date(); // До сьогодні

    // Проходимо по кожному місяцю
    for (let d = new Date(startDate); d <= endDate; d.setMonth(d.getMonth() + 1)) {
      const year = d.getFullYear();
      const month = d.toLocaleString('uk-UA', { month: 'long' });

      for (const employee of employees) {
        // Логіка: інколи даємо премію (кожен 3-й місяць)
        const isBonusMonth = (d.getMonth() + 1) % 3 === 0;
        const grossAmount = isBonusMonth ? employee.fixedSalary * 1.1 : employee.fixedSalary;
        
        // Податки
        const pdfo = grossAmount * 0.18;
        const military = grossAmount * 0.05; // 5% як у нових вимогах
        const netAmount = grossAmount - pdfo - military;

        salaryRecords.push({
          user: employee._id,
          grossAmount: Math.round(grossAmount),
          taxes: {
            pdfo: Math.round(pdfo),
            military: Math.round(military)
          },
          netAmount: Math.round(netAmount),
          accrualDate: new Date(d), // Копія дати
          comment: isBonusMonth ? `ЗП за ${month} ${year} + Премія` : `ЗП за ${month} ${year}`,
          status: 'approved', // Одразу затверджено
          approvedBy: manager ? manager._id : employee._id, // Якщо менеджера немає, підписує сам (для тестів)
          approvalDate: new Date(d.setDate(d.getDate() + 1)) // Затверджено наступного дня
        });
      }
    }

    await Salary.insertMany(salaryRecords);
    console.log(`✅ Успішно створено ${salaryRecords.length} записів про зарплату`);

    console.log('🎉 Seed завершено!');
    process.exit();

  } catch (err) {
    console.error('❌ Помилка:', err);
    process.exit(1);
  }
};

seedDB();