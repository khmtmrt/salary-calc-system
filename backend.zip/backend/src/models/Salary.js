const mongoose = require('mongoose');

const SalarySchema = new mongoose.Schema({
  user: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User',
    required: true 
  },
  grossAmount: { type: Number, required: true },
  taxes: {
    pdfo: { type: Number, required: true },
    military: { type: Number, required: true }
  },
  netAmount: { type: Number, required: true },
  accrualDate: { type: Date, default: Date.now },
  comment: { type: String },
  
  // --- НОВІ ПОЛЯ ---
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected'], // pending - чекає, approved - затверджено
    default: 'pending'
  },
  approvedBy: { // Хто затвердив (Керівник)
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User' 
  },
  approvalDate: { type: Date }
});

module.exports = mongoose.model('Salary', SalarySchema);