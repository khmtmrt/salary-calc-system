const authService = require('../services/authService');

class AuthController {
  
  async register(req, res) {
    try {
      const { email, password, name } = req.body;
      // Викликаємо сервіс
      const userData = await authService.registration(email, password, name);
      // Відповідь клієнту
      return res.status(201).json(userData);
    } catch (e) {
      console.log(e);
      // Повертаємо помилку, яку викинув сервіс
      res.status(400).json({ message: e.message });
    }
  }

  async login(req, res) {
    try {
      const { email, password } = req.body;
      const data = await authService.login(email, password);
      return res.json(data);
    } catch (e) {
      console.log(e);
      res.status(400).json({ message: e.message });
    }
  }
}

module.exports = new AuthController();