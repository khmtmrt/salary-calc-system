const salaryService = require('../services/salaryService');

class SalaryController {

  async accrue(req, res) {
    try {
      const accountantId = req.user.id; 
      const { userId, grossAmount, comment } = req.body;

      if (!userId || !grossAmount) {
        return res.status(400).json({ message: 'Вкажіть дані' });
      }

      const result = await salaryService.accrueSalary(accountantId, userId, grossAmount, comment);
      res.status(201).json({ message: 'Створено. Очікує затвердження керівником.', data: result });
    } catch (e) {
      res.status(400).json({ message: e.message });
    }
  }

  async approve(req, res) {
    try {
      const managerId = req.user.id;
      const { id } = req.params; 

      const result = await salaryService.approveSalary(id, managerId);
      res.json({ message: 'Зарплату успішно затверджено', data: result });
    } catch (e) {
      res.status(400).json({ message: e.message });
    }
  }

  // НОВИЙ МЕТОД: Отримати всі (для менеджера)
  async getAll(req, res) {
    try {
      // Витягуємо параметри фільтрації з URL
      // Приклад: GET /api/salary/all?period=month&status=pending
      const filters = req.query; 
      
      const salaries = await salaryService.getAllSalaries(filters);
      res.json(salaries);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  }

  async getHistory(req, res) {
    try {
      const { userId } = req.params;
      const history = await salaryService.getUserSalaryHistory(userId, req.user.role);
      res.json(history);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  }

  async getSlip(req, res) {
    try {
      const slip = await salaryService.getSalarySlip(req.params.id);
      res.json(slip);
    } catch (e) {
      res.status(404).json({ message: e.message });
    }
  }
}

module.exports = new SalaryController();