const adminService = require('../services/adminService');

class AdminController {

  // GET /api/admin/users
  async getAll(req, res) {
    try {
      const users = await adminService.getAllUsers();
      return res.json(users);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  }

  // POST /api/admin/users
  async create(req, res) {
    try {
      const user = await adminService.createUser(req.body);
      return res.status(201).json(user);
    } catch (e) {
      res.status(400).json({ message: e.message });
    }
  }

  // PUT /api/admin/users/:id
  async update(req, res) {
    try {
      const updatedUser = await adminService.updateUser(req.params.id, req.body);
      return res.json(updatedUser);
    } catch (e) {
      res.status(400).json({ message: e.message });
    }
  }

  // PUT /api/admin/users/:id/password
  async changePassword(req, res) {
    try {
      const { password } = req.body;
      if (!password) {
        return res.status(400).json({ message: 'Пароль обов\'язковий' });
      }
      const result = await adminService.changeUserPassword(req.params.id, password);
      return res.json(result);
    } catch (e) {
      res.status(400).json({ message: e.message });
    }
  }

  // DELETE /api/admin/users/:id
  async delete(req, res) {
    try {
      const user = await adminService.deleteUser(req.params.id);
      return res.json({ message: 'Користувача видалено', id: user._id });
    } catch (e) {
      res.status(400).json({ message: e.message });
    }
  }
}

module.exports = new AdminController();