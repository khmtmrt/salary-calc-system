const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

class AuthService {
  
  async registration(email, password, name) {
    const candidate = await User.findOne({ email });
    if (candidate) throw new Error('Користувач з таким email вже існує');

    const hashPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ email, password: hashPassword, name, fixedSalary: 0 });
    return user;
  }

  async login(email, password) {
    const user = await User.findOne({ email });
    if (!user) throw new Error('Користувача не знайдено');

    const isPassEquals = await bcrypt.compare(password, user.password);
    if (!isPassEquals) throw new Error('Невірний пароль');

    // Додаємо fixedSalary в payload токена
    const payload = { 
        id: user._id, 
        role: user.role, 
        email: user.email, 
        name: user.name,
        fixedSalary: user.fixedSalary 
    };
    
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

    return { token, user };
  }
}

module.exports = new AuthService();