const User = require('../models/User');
const bcrypt = require('bcryptjs');

class AdminService {

  async getAllUsers() {
    return await User.find().select('-password');
  }

  async createUser(data) {
    const { email, password, name, role, fixedSalary } = data;

    const candidate = await User.findOne({ email });
    if (candidate) {
      throw new Error('Користувач з таким email вже існує');
    }

    const hashPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      email,
      password: hashPassword,
      name,
      role: role || 'user',
      fixedSalary: fixedSalary || 0 // Зберігаємо ставку
    });

    return user;
  }

  async updateUser(id, data) {
    // Додаємо fixedSalary до дозволених полів для оновлення
    const user = await User.findByIdAndUpdate(
      id, 
      { $set: data }, 
      { new: true }
    ).select('-password');

    if (!user) throw new Error('Користувача не знайдено');
    return user;
  }

  async changeUserPassword(id, newPassword) {
    const hashPassword = await bcrypt.hash(newPassword, 10);
    const user = await User.findByIdAndUpdate(id, { password: hashPassword }, { new: true });
    if (!user) throw new Error('Користувача не знайдено');
    return { message: 'Пароль успішно змінено' };
  }

  async deleteUser(id) {
    const user = await User.findByIdAndDelete(id);
    if (!user) throw new Error('Користувача не знайдено');
    return user;
  }
}

module.exports = new AdminService();