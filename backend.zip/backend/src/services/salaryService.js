const Salary = require('../models/Salary');
const User = require('../models/User');

class SalaryService {

  async accrueSalary(accountantId, userId, grossAmount, comment) {
    const user = await User.findById(userId);
    if (!user) throw new Error('Співробітника не знайдено');

    const lastSalary = await Salary.findOne({ user: userId }).sort({ accrualDate: -1 });
    if (lastSalary) {
      const now = new Date();
      const lastDate = new Date(lastSalary.accrualDate);
      const diffDays = Math.ceil(Math.abs(now - lastDate) / (1000 * 60 * 60 * 24)); 
      if (diffDays < 14) {
        throw new Error(`Зарплата вже нараховувалася ${diffDays} днів тому.`);
      }
    }

    const pdfo = grossAmount * 0.18;
    const military = grossAmount * 0.05;
    const netAmount = grossAmount - pdfo - military;

    const salaryRecord = await Salary.create({
      user: userId,
      grossAmount,
      taxes: { pdfo, military },
      netAmount,
      comment,
      accrualDate: new Date()
    });

    return salaryRecord;
  }

  async approveSalary(salaryId, managerId) {
    const salary = await Salary.findById(salaryId);
    if (!salary) throw new Error('Платіжку не знайдено');

    if (salary.status === 'approved') {
      throw new Error('Ця платіжка вже затверджена');
    }

    salary.status = 'approved';
    salary.approvedBy = managerId;
    salary.approvalDate = new Date();
    
    await salary.save();
    return salary;
  }

  // --- НОВИЙ МЕТОД: Отримання всіх зарплат з фільтрами ---
  async getAllSalaries(filters) {
    const { period, startDate, endDate, status } = filters;
    let dateQuery = {};

    const now = new Date();

    // Логіка фільтрації за датою
    if (startDate && endDate) {
        // Кастомний діапазон
        dateQuery = { 
            $gte: new Date(startDate), 
            $lte: new Date(endDate) 
        };
    } else if (period) {
        // Швидкі фільтри
        if (period === 'week') {
            const startOfWeek = new Date(now);
            startOfWeek.setDate(now.getDate() - 7); // Останні 7 днів
            dateQuery = { $gte: startOfWeek };
        } 
        else if (period === 'month') {
            const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
            dateQuery = { $gte: startOfMonth };
        } 
        else if (period === 'quarter') {
            const currentQuarter = Math.floor(now.getMonth() / 3);
            const startMonth = currentQuarter * 3;
            const startOfQuarter = new Date(now.getFullYear(), startMonth, 1);
            dateQuery = { $gte: startOfQuarter };
        }
    }

    // Формування запиту до БД
    const query = {};
    
    // Додаємо фільтр дати, якщо він є
    if (Object.keys(dateQuery).length > 0) {
        query.accrualDate = dateQuery;
    }

    // Додаємо фільтр статусу (наприклад, тільки pending)
    if (status) {
        query.status = status;
    }

    return await Salary.find(query)
      .populate('user', 'email name role')
      .populate('approvedBy', 'name email')
      .sort({ accrualDate: -1 });
  }

  async getUserSalaryHistory(userId, requestorRole) {
    let query = { user: userId };
    if (requestorRole === 'user') {
      query.status = 'approved';
    }
    return await Salary.find(query)
      .populate('user', 'email name role')
      .populate('approvedBy', 'name email')
      .sort({ accrualDate: -1 });
  }

  async getSalarySlip(salaryId) {
    const slip = await Salary.findById(salaryId)
      .populate('user', 'name email')
      .populate('approvedBy', 'name');
    if (!slip) throw new Error('Платіжку не знайдено');
    return slip;
  }
}

module.exports = new SalaryService();