const jwt = require('jsonwebtoken');

module.exports = function (roles) {
    return function (req, res, next) {
        if (req.method === "OPTIONS") {
            next();
        }

        try {
            const token = req.headers.authorization.split(' ')[1];
            if (!token) {
                return res.status(401).json({message: "Користувач не авторизований"});
            }
            
            // Ми могли б взяти роль з req.user (якщо authMiddleware був першим),
            // але для надійності перевіряємо токен ще раз або покладаємось на порядок виклику.
            // Оскільки в маршрутах ми викликаємо authMiddleware першим, 
            // то тут можна просто перевірити req.user.role, якщо authMiddleware вже відпрацював.
            
            // Варіант А: (незалежний, декодуємо знову)
            const {role: userRole} = jwt.verify(token, process.env.JWT_SECRET);
            
            let hasRole = false;
            // Перевіряємо, чи роль користувача є в списку дозволених ролей
            if (roles.includes(userRole)) {
                hasRole = true;
            }
            
            if (!hasRole) {
                return res.status(403).json({message: "У вас немає доступу"});
            }
            next();
        } catch (e) {
            console.log(e);
            return res.status(403).json({message: "Користувач не авторизований"});
        }
    }
};