const Router = require('express');
const router = new Router();
const controller = require('../controllers/adminController');

// ПРИПУЩЕННЯ: Ваші middleware знаходяться в папці ../middleware
// Якщо ні - скоригуйте шлях або додайте код middleware сюди
const authMiddleware = require('../middleware/authMiddleware'); // Перевірка токена
const roleMiddleware = require('../middleware/roleMiddleware'); // Перевірка ролі

// Цей middleware застосовується до ВСІХ маршрутів нижче
// Спочатку перевіряємо токен, потім чи є юзер адміном
// Примітка: roleMiddleware має бути функцією, що повертає middleware, або просто middleware, який перевіряє req.user.role === 'admin'
router.use(authMiddleware, roleMiddleware(['admin', 'accountant']));

// Отримати всіх
router.get('/users', controller.getAll);

// Створити користувача
router.post('/users', controller.create);

// Оновити дані користувача (ім'я, роль, email)
router.put('/users/:id', controller.update);

// Змінити пароль користувачу (окремий маршрут)
router.put('/users/:id/password', controller.changePassword);

// Видалити користувача
router.delete('/users/:id', controller.delete);

module.exports = router;