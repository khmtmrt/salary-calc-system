const Router = require('express');
const router = new Router();
const controller = require('../controllers/salaryController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

// Базовий захист: токен має бути у всіх
router.use(authMiddleware);

// 1. Нарахувати (Бухгалтер або Адмін)
router.post('/accrue', 
    roleMiddleware(['accountant', 'admin']), 
    controller.accrue
);

// 2. Затвердити (ТІЛЬКИ Менеджер або Адмін)
// Використовується для затвердження конкретної платіжки
router.put('/approve/:id', 
    roleMiddleware(['manager', 'admin']), 
    controller.approve
);

// 3. Отримати ВСІ платіжки (Для Менеджера: звітність та контроль)
// Підтримує фільтри: ?period=month, ?status=pending, ?startDate=...
router.get('/all', 
    roleMiddleware(['manager', 'admin']), 
    controller.getAll
);

// 4. Історія конкретного юзера (Доступно всім, але сервіс фільтрує дані залежно від ролі)
router.get('/history/:userId', controller.getHistory);

router.get('/slip/:id', controller.getSlip);

module.exports = router;