require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRouter = require('./src/routes/authRoutes'); // Імпорт роутера
const adminRouter = require('./src/routes/adminRoutes');
const salaryRouter = require('./src/routes/salaryRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Підключаємо маршрути
// Всі маршрути з файлу authRoutes будуть починатися з /api/auth
app.use('/api/auth', authRouter); 
app.use('/api/admin', adminRouter);
app.use('/api/salary', salaryRouter);

const start = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
  } catch (e) {
    console.log(e);
  }
}

start();


// api/auth/login